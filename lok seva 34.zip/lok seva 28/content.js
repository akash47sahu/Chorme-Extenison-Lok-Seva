var count = 0;
chrome.runtime.onMessage.addListener(

  function(request) {

count = count+1;
if (count ==1){
       var table = document.getElementById("ctl00_ContentPlaceHolder1_Tbl_Rpt");
        var list_1 = [];
        for (var i = 2 ; i < table.rows.length; i++) {

        var text_td = table.rows[i].cells[7].innerText;
        if (text_td == 'N'){
                    var row = "";
                row += table.rows[i].cells[1].innerText;
                row += ","
                var str = table.rows[i].cells[4].innerText;
                  row += str.substring(1);
        var k = i-2;
           var click = 'ctl00_ContentPlaceHolder1_btn_Upload'+k+','+ row;
    var id_click = click.replace(/\s+/g, '')
    list_1.push(id_click);
        }
        }

window.value = list_1;
if (typeof list_1 !== 'undefined' && list_1.length > 0) {
   trying();
}
else{alert("No Send Attempt 'N' entry found.Select another date.Press enter")}
return
}
  });


function trying(){

chrome.runtime.sendMessage({hi: window.value}, function(response) {
console.log(response.ok);
});
  return true;
}


