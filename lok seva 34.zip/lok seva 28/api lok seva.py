from flask import Flask
from flask_restful import Resource, Api
import pandas as pd
import xlrd
import xlsxwriter
from xlsxwriter.utility import xl_rowcol_to_cell
from xlrd import open_workbook

app = Flask(__name__)
api = Api(app)

class Quotes(Resource):
    @app.route('/check/<email>')
    def get(email):

        data = pd.read_excel(r'lsk_name.xlsx')  # place "r" before the path string to address special character, such as '\'. Don't forget to put the file name at the end of the path + '.xlsx'
        if email in data.values:
            value = 'Found'
        else:
            value = 'NOT Found'

        return {
            'Result': value,'msg':'success'
        }

api.add_resource(Quotes, '/check')

if __name__ == '__main__':
    app.run(debug=True)
