function starting(){

  var user = chrome.tabs.executeScript(null,{code:" document.getElementById('ctl00_lblUSername').innerText;"},
  function(user){
    $.postJSON = function(url,  success, args) {
        args = $.extend({
        url: 'http://103.240.90.190:89/check/'+user,

        type: 'GET',

        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        async: true,
        success: success
       }, args);
     return $.ajax(args);
     }
          $.postJSON(' http://103.240.90.190:89/check',  function(messages) {

          console.log(messages.Result)

          if (messages.Result == "Found"){
            awesome()
             }
          else{
          alert("username not registered.Press Enter..")
  chrome.tabs.executeScript(null,{code:" document.getElementById('A4').click();"});
    return
          }
});
});
}


function awesome() {

chrome.tabs.executeScript(
  null,{file: "jquery-3.4.1.min.js"},
  function() {
    chrome.tabs.executeScript(null, {file: "content.js"}, afterInject);
  });

function afterInject(){
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {greeting: "hello"}
   );
  }) ;

};
};


chrome.runtime.onMessage.addListener(

async  function(request, sender, sendResponse) {
        var id_list = request.hi;

        await new Promise(resolve => setTimeout(resolve,3000));
        var len_list = id_list.length;
        var logout = len_list + 1 ;
        window.value = logout ;
        var interval = 35000;


await new Promise(resolve => setTimeout(resolve,2000));
for (let i = 0; i <= logout; i++) {
    setTimeout( trying, interval * i,i);
}

sendResponse({ok: 'bye'});
});



document.addEventListener('DOMContentLoaded', function () {
  document.getElementById("start").addEventListener('click', starting);
  document.getElementById("stop").addEventListener('click', StopFunction);

});

function StopFunction(){
chrome.runtime.reload();
return
}

function trying(item){


var count = 0 ;
var kill_tab = 0 ;

if (item == window.value){
  chrome.tabs.query({},async function(tabs) {
    for (var i=tabs.length-1; i>=0; i--) {
    if (tabs[i].url == "http://www.mpedistrict.gov.in/AuthUser/LSK_TatkalRegDetails.aspx")
    {
   chrome.tabs.update(tabs[i].id, {active: true},async function(tab){
        chrome.tabs.executeScript(null,{code:" document.getElementById('A4').click();"});
    });
    return
    }    }    })  }

else{
  chrome.tabs.query({},async function(tabs) {
    for (var i=tabs.length-1; i>=0; i--) {
    if (tabs[i].url == "http://www.mpedistrict.gov.in/AuthUser/LSK_TatkalRegDetails.aspx")
    {   kill_tab = kill_tab + 1;
        chrome.tabs.update(tabs[i].id, {active: true},async function(tab){

        chrome.tabs.executeScript(null,{code:" document.getElementById('ctl00_ContentPlaceHolder1_btnsubmit').click();"});
            await new Promise(resolve => setTimeout(resolve,3000));
        chrome.tabs.executeScript(null,{code:" document.evaluate('/html/body/form/div[3]/table/tbody/tr[3]/td/table/tbody/tr[1]/td/table/tbody/tr/td/table/tbody/tr[12]/td/div/table[2]/tbody/tr[3]/td[7]/input', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()"});

            });
      }
     }
     });  }

chrome.tabs.onCreated.addListener(async function(tab) {
            var tab_id = tab.id ;
      await new Promise(resolve => setTimeout(resolve,1000));
   if (kill_tab == 1) {
                    setTimeout(function(){
                    if (count == 0){
                    chrome.tabs.remove(tab.id);
                    count = count+1;
                    return;} },26000)
                        }
try{
        await new Promise(resolve => setTimeout(resolve,1000));
        waitForElement(tab_id,3000);

        async function waitForElement(tab_id,time) {
          var send_id =  document.querySelectorAll('#action-button');
         if (send_id !=null) {
            chrome.tabs.executeScript(tab_id,{code:" document.getElementById('action-button').click();"});
            await new Promise(resolve => setTimeout(resolve,1000));
            whatsappWeb()
            return;
              }
        else {
            setTimeout(function() {
                waitForElement(tab_id,3000);
            }, 3000);
        }
    }

    async function whatsappWeb(tab_id){
    await new Promise(resolve => setTimeout(resolve,2000));
    chrome.tabs.executeScript(tab_id,{code:" document.evaluate('/html/body/div[1]/div/div[2]/div/div[2]/div/div/a', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()"});
    await new Promise(resolve => setTimeout(resolve,1000));
    chrome.tabs.executeScript(tab_id,{code:" document.evaluate('/html/body/div[1]/div/div[2]/div/div[2]/div/div/a', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()"});
                }

      await new Promise(resolve => setTimeout(resolve,5000));

     chrome.tabs.executeScript(tab_id,{code:"document.querySelector('._1U1xa').click()"});

     await new Promise(resolve => setTimeout(resolve,1000));
     chrome.tabs.executeScript(tab_id,{code:"document.querySelector('._1U1xa').click()"});
     await new Promise(resolve => setTimeout(resolve,2000));
     chrome.tabs.executeScript(tab_id,{code:"document.querySelector('._1U1xa').click()"});
           }
    catch(err1) {
    console.log(err1.message);
    }
    });

}